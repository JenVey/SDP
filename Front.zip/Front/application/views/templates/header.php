<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>gather.owl</title>
<link rel="icon" href="<?php echo base_url();?>/asset/Images/android-chrome-512x512.png">
<link rel="stylesheet" href="<?php echo base_url();?>/asset/CSS/bootstrap.css">
<link rel="stylesheet" href="<?php echo base_url();?>/asset/CSS/Ours.css">
</head>
